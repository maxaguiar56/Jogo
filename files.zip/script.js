document.addEventListener("DOMContentLoaded", () => {
    const startCell = document.getElementById("start");
    const finishCell = document.getElementById("finish");
    let currentCell = startCell;

    startCell.addEventListener("click", () => {
        currentCell = startCell;
        startCell.style.backgroundColor = "yellow";
    });

    const cells = document.querySelectorAll(".cell");
    cells.forEach(cell => {
        cell.addEventListener("click", () => {
            if (cell.classList.contains("path") || cell.classList.contains("finish")) {
                currentCell.style.backgroundColor = "white";
                cell.style.backgroundColor = "yellow";
                currentCell = cell;
                if (cell === finishCell) {
                    alert("Você venceu!");
                }
            }
        });
    });
});